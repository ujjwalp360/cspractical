-- Create the database
CREATE DATABASE IF NOT EXISTS CBSE24;

-- Use the created database
USE CBSE24;

-- Create the PRODUCT table
CREATE TABLE IF NOT EXISTS PRODUCT (
    P_ID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(255),
    Manufacturer VARCHAR(255),
    Price DECIMAL(10, 2),
    ExpiryDate DATE
);

-- Create the CLIENT table
CREATE TABLE IF NOT EXISTS CLIENT (
    C_ID INT AUTO_INCREMENT PRIMARY KEY,
    ClientName VARCHAR(255),
    City VARCHAR(255),
    P_ID INT,
    FOREIGN KEY (P_ID) REFERENCES PRODUCT(P_ID)
);

-- Insert data into the PRODUCT table
INSERT INTO PRODUCT (ProductName, Manufacturer, Price, ExpiryDate) VALUES
('Talcum Powder', 'LAK40', 20.00, '2011-06-26'),
('Face Wash', 'ABC45', 25.00, '2010-12-01'),
('Bath Soap', 'ABC55', 15.00, '2010-09-10'),
('Shampoo', 'XYZ12', 30.00, '2012-04-09'),
('Face Wash', 'XYZ95', 20.00, '2010-08-15');

-- Insert data into the CLIENT table
INSERT INTO CLIENT (ClientName, City, P_ID) VALUES
('Cosmetic Shop', 'Delhi', NULL),
('Total Health', 'Mumbai', 2),
('Live Life', 'Delhi', 4),
('Pretty One', 'Delhi', 5),
('Dreams', 'Bengaluru', 1),
('Expressions', 'Delhi', NULL);
---------------------------------------------------------------------------------------------
-- To display the ClientName and City of all Mumbai- and Delhi-based clients in the Client table
SELECT ClientName, City
FROM CLIENT
WHERE City IN ('Mumbai', 'Delhi');

-- Increase the price of all the products in the Product table by 10%
UPDATE PRODUCT
SET Price = Price * 1.10;

-- To display the ProductName, Manufacturer, ExpiryDate of all the products that expired on or before ‘2010-12-31’
SELECT ProductName, Manufacturer, ExpiryDate
FROM PRODUCT
WHERE ExpiryDate <= '2010-12-31';

-- To display C_ID, ClientName, City of all the clients (including the ones that have not purchased a product) and their corresponding ProductName sold
SELECT C.C_ID, C.ClientName, C.City, P.ProductName
FROM CLIENT C
LEFT JOIN PRODUCT P ON C.P_ID = P.P_ID OR P.P_ID IS NULL;
