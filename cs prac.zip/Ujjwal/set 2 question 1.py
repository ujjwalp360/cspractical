PLAYER = []  # List to store player records (stack)

def PUSH():
    # Get data of 3 players from the user
    for _ in range(3):
        player_code = input("Enter Player Code: ")
        name = input("Enter Player Name: ")
        rank = input("Enter Player Rank: ")

        # Create a tuple with player details and push it onto the stack
        player_record = (player_code, name, rank)
        PLAYER.append(player_record)

    print("Player records added successfully.")

def POP():
    if not PLAYER:
        print("Stack is empty. No player records to remove.")
    else:
        # Remove the last record from the stack
        removed_player = PLAYER.pop()
        print(f"Removed Player Record: {removed_player}")

def Display_Player():
    if not PLAYER:
        print("Stack is empty. No player records to display.")
    else:
        print("\nPlayer Records:")
        for player_record in reversed(PLAYER):
            print("Player Code:", player_record[0])
            print("Player Name:", player_record[1])
            print("Player Rank:", player_record[2])
            print("-------------------------------")

# Menu-based program
while True:
    print("\nMenu:")
    print("1. Add Player Records (PUSH)")
    print("2. Remove Last Player Record (POP)")
    print("3. Display Player Records")
    print("4. Exit")

    choice = input("Enter your choice (1-4): ")

    if choice == '1':
        PUSH()
    elif choice == '2':
        POP()
    elif choice == '3':
        Display_Player()
    elif choice == '4':
        print("Exiting the program. Goodbye!")
        break
    else:
        print("Invalid choice. Please enter a valid option.")
