import csv

def ADDPROD():
    # Get data of a product from the user
    prodid = input("Enter Product ID: ")
    name = input("Enter Product Name: ")
    price = input("Enter Product Price: ")

    # Create a list with product details
    product_record = [prodid, name, price]

    # Append the record to the 'product.csv' file
    with open('product.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(product_record)

    print("Product details added successfully.")

def COUNTPROD():
    try:
        # Open the 'product.csv' file and count the number of records
        with open('product.csv', 'r') as file:
            reader = csv.reader(file)
            num_records = 0
            for _ in reader:
                num_records += 1
        
        print(f"Number of records in 'product.csv': {num_records}")
    except FileNotFoundError:
        print("File 'product.csv' not found. No records to count.")

# Call the functions
ADDPROD()
COUNTPROD()
