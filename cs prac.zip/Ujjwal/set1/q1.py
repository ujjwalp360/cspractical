'''PYTHON PROGRAMMING\
Write program in Python that defines and calls the following user defined functions:\
(i)COURIER_ADD(): It takes the values from the user and adds the details to a csv file 'courier.csv. Each record consists of a list with field elements as cid, s_name, Source, destination store Courier ID, Sender name, Source and destination address respectively.\
(ii) COURIER_SEARCH (): Takes the destination as the input and displays all the courier records going to that destination.'''
import csv

def COURIER_ADD():
    cid = input("Enter Courier ID: ")
    sname = input("Enter Sender name: ")
    src = input("Enter Source: ")
    dest = input("Enter Destination: ")

    with open('courier.csv', mode='a+', ) as f:
        writer = csv.writer(f)
        writer.writerow([cid, sname, src, dest])

def COURIER_SEARCH():
    d = input("Enter Destination to search: ")
    with open('courier.csv', mode='r') as f:
        reader = csv.reader(f)
        for i in reader:
            if i[3] == d:
                print(i)

while True:
    choice = input("Enter 1 to add courier details, 2 to search by destination, or 0 to exit: ")
    if choice == '1':
        COURIER_ADD()
    elif choice == '2':
        COURIER_SEARCH()
    elif choice == '0':
        break
    else:
        print("Invalid choice. Please enter again.")
