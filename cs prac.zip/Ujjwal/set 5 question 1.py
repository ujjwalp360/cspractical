import pickle

def insert():
    # Creating data in the form of dictionaries
    data = [
        {"Rollno": 101, "Name": "John", "Age": 18},
        {"Rollno": 102, "Name": "Alice", "Age": 16},
        {"Rollno": 103, "Name": "Bob", "Age": 20}
    ]

    # Writing the dictionaries to the binary file 'data.dat'
    with open('data.dat', 'wb') as file:
        pickle.dump(data, file)

    print("Data inserted into 'data.dat' successfully.")

def read():
    try:
        # Reading data from the binary file 'data.dat'
        with open('data.dat', 'rb') as file:
            data = pickle.load(file)

        # Displaying dictionaries with age 16
        print("\nDictionaries with Age 16:")
        for record in data:
            if record["Age"] == 16:
                print(record)
    except FileNotFoundError:
        print("File 'data.dat' not found. Please insert data first.")

# Call the functions
insert()
read()
