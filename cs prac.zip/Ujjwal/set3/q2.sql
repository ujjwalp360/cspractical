-- Create the database
CREATE DATABASE CBSE24;

-- Use the newly created database
USE CBSE24;

-- Create the STUDENT table
CREATE TABLE STUDENT (
    Enrol INT PRIMARY KEY,
    SName VARCHAR(50),
    Fee INT,
    House VARCHAR(20),
    Class INT,
    Grade VARCHAR(5),
    Scode VARCHAR(5)
);

-- Insert data into the STUDENT table
INSERT INTO STUDENT (Enrol, SName, Fee, House, Class, Grade, Scode)
VALUES 
    (101, 'Nanda', 5000, 'Green', 11, 'A', 'S11'),
    (102, 'Saurabh', 3000, 'Blue', 12, 'B', 'S33'),
    (103, 'Kamal', 3000, 'Green', 12, NULL, 'S33'),
    (104, 'Praveen', 2500, 'Red', 11, 'C', 'S11'),
    (105, 'Arvind', 4500, 'Blue', 12, NULL, 'S22');

-- Create the STREAMS table
CREATE TABLE STREAMS (
    Scode VARCHAR(5) PRIMARY KEY,
    Sname VARCHAR(50),
    Chapters INT
);

-- Insert data into the STREAMS table
INSERT INTO STREAMS (Scode, Sname, Chapters)
VALUES 
    ('S11', 'Science', 15),
    ('S22', 'Commerce', 11),
    ('S33', 'Humanities', 12);
------------------------------------------------------------------------------
-- 1. Display the details of all the students who are paying fee less than 3000.
SELECT *
FROM STUDENT
WHERE Fee < 3000;

-- 2. Display the sum of fee of Class 11 students.
SELECT SUM(Fee) AS Total_Fee_Class_11
FROM STUDENT
WHERE Class = 11;

-- 3. Display the student name, class, fee, and House of students in ascending order of their fee of Blue department.
SELECT SName, Class, Fee, House
FROM STUDENT
WHERE House = 'Blue'
ORDER BY Fee ASC;

-- 4. Display Student Enrolment no, Student Name, and Stream Name for all students.
SELECT s.Enrol, s.SName, st.Sname AS Stream_Name
FROM STUDENT s
INNER JOIN STREAMS st ON s.Scode = st.Scode;
