'''PYTHON PROGRAMMING
Write a menu-based program to add, delete and display the Books Record by using list as Stack in python. (Record of a  Book contains: Book code, name and Price). The program should contain following three functions: 
(i) PUSH() – to get the data of 3 Book from the user  and add them to stack Books
(ii) POP() – to remove the last record from the  stack Books
(iii) Display_Books() – To display all records from the stack
'''

b = []  

def PUSH():
    for i in range(3):
        c=input("Code: ")
        n=input("Name: ")
        p=input("Price: ")
        b.append((c, n, p))
    print("Books added.")

# Function to remove the last book record from the stack
def POP():
    if b:
        b.pop()
        print("Last book removed.")
    else:
        print("Stack is empty.")

# Function to display all book records from the stack
def Display_Books():
    if b:
        print("Books Record:")
        for i in b:
            print(f"Code: {i[0]} Name: {i[1]} Price: {i[2]}")
    else:
        print("Stack is empty.")

while True:
    print("Menu:")
    print("1. Add Books")
    print("2. Delete Last Book")
    print("3. Display Books")
    print("4. Exit")
    choice = input("Enter choice: ")

    if choice == '1':
        PUSH()
    elif choice == '2':
        POP()
    elif choice == '3':
        Display_Books()
    elif choice == '4':
        print("Exiting.")
        break
    else:
        print("Invalid choice.")
