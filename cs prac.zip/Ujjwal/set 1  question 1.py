import csv

def COURIER_ADD():
    # Get details from the user
    cid = input("Enter Courier ID: ")
    s_name = input("Enter Sender Name: ")
    source = input("Enter Source Address: ")
    destination = input("Enter Destination Address: ")

    # Create a list with the entered details
    record = [cid, s_name, source, destination]

    # Append the record to the 'courier.csv' file
    with open('courier.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(record)

    print("Courier details added successfully.")

def COURIER_SEARCH():
    # Get the destination input from the user
    search_destination = input("Enter Destination to search: ")

    # Read the 'courier.csv' file and display matching records
    with open('courier.csv', 'r') as file:
        reader = csv.reader(file)
        found_records = [record for record in reader if record[3].lower() == search_destination.lower()]

    if not found_records:
        print("No couriers found for the given destination.")
    else:
        print("\nMatching Courier Records:")
        for record in found_records:
            print("Courier ID:", record[0])
            print("Sender Name:", record[1])
            print("Source Address:", record[2])
            print("Destination Address:", record[3])
            print("-------------------------------")

# Call the functions
COURIER_ADD()
COURIER_SEARCH()
