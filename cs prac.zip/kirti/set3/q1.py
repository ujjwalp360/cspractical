'''PYTHON PROGRAMMING
Write a menu-based program to add, delete and display the Books Record by using list as Stack in python. (Record of a  Book contains: Book code, name and Price). The program should contain following three functions: 
(i) PUSH() – to get the data of 3 Book from the user  and add them to stack Books
(ii) POP() – to remove the last record from the  stack Books
(iii) Display_Books() – To display all records from the stack
'''

books = []  

def PUSH():
    for _ in range(3):
        books.append((input("Code: "), input("Name: "), input("Price: ")))
    print("Books added.")

# Function to remove the last book record from the stack
def POP():
    if books:
        books.pop()
        print("Last book removed.")
    else:
        print("Stack is empty.")

# Function to display all book records from the stack
def Display_Books():
    if books:
        print("Books Record:")
        for book in reversed(books):
            print(f"Code: {book[0]}\nName: {book[1]}\nPrice: {book[2]}")
    else:
        print("Stack is empty.")

while True:
    print("\nMenu:")
    print("1. Add Books")
    print("2. Delete Last Book")
    print("3. Display Books")
    print("4. Exit")
    choice = input("Enter choice: ")

    if choice == '1':
        PUSH()
    elif choice == '2':
        POP()
    elif choice == '3':
        Display_Books()
    elif choice == '4':
        print("Exiting.")
        break
    else:
        print("Invalid choice.")
