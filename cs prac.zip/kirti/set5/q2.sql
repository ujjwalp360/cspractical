-- Create Database
CREATE DATABASE IF NOT EXISTS CBSE24;
USE CBSE24;

-- Create Flight Table
CREATE TABLE IF NOT EXISTS Flight (
    flightid INT PRIMARY KEY,
    model VARCHAR(50),
    company VARCHAR(50)
);

-- Create Booking Table
CREATE TABLE IF NOT EXISTS Booking (
    ticketno INT PRIMARY KEY,
    passengers VARCHAR(50),
    source VARCHAR(50),
    destination VARCHAR(50),
    quantity INT,
    price DECIMAL(10, 2),
    Flightid INT,
    FOREIGN KEY (Flightid) REFERENCES Flight(flightid)
);

-- Insert Sample Data into Flight Table
INSERT INTO Flight (flightid, model, company)
VALUES
    (10,747, 'Boeing'),
    (12,320, 'Airbus'),
    (15,767, 'Boeing');

-- Insert Sample Data into Booking Table
INSERT INTO Booking (ticketno, passengers, source, destination, quantity, price, Flightid)
VALUES
    (10001, 'ARUN', 'BANDEL', '270001', 2, 7000, 10),
    (10002, 'ORAM', 'BANKOL', '375001', 3, 7500, 12),
    (10003, 'SUMITA', 'DEL', 'MUM', 1, 6000, 15),
    (10004, 'ALI', 'MUM', 'KOL', 2, 5600, 10),
    (10005, 'GAGAN', 'MUM', 'DEL', 4, 5000, 12);

-- Display the ClientName and City of all Mumbai- and Delhi-based clients in Client table
SELECT ClientName, City
FROM Client
WHERE City IN ('Mumbai', 'Delhi');

-- Increase the price of all the products in Product table by 10%
UPDATE Product
SET Price = Price * 1.1;

-- Display the ProductName, Manufacturer, ExpiryDate of all the products that expired on or before '2010-12-31'
SELECT ProductName, Manufacturer, ExpiryDate
FROM Product
WHERE ExpiryDate <= '2010-12-31';

-- Display C_ID, ClientName, City of all the clients (including the ones that have not purchased a product) and their corresponding ProductName sold
SELECT C.C_ID, C.ClientName, C.City, P.ProductName
FROM Client C
LEFT JOIN Purchase P ON C.C_ID = P.C_ID;
