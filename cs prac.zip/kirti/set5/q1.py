'''PYTHON PROGRAMMING
A binary file data.dat needs to be created with following data written it in the form of Dictionaries.
Rollno Name Age
Write the following functions in python accommodate the data and manipulate it.
(A) A function insert() that creates the data.dat file in your system and writes the three dictionaries.
(B) A function() read() that reads the data from the binary file and displays the dictionaries whose age is 16.
'''

import pickle

def insert(data):
    with open('data.dat', 'wb') as file:
        pickle.dump(data, file)

def read():
    with open('data.dat', 'rb') as file:
        data = pickle.load(file)
        for person in data:
            if person['Age'] == 16:
                print(person)

# Example usage:
data = [
    {'Rollno': 1, 'Name': 'xyz', 'Age': 16},
    {'Rollno': 2, 'Name': 'abc', 'Age': 18},
    {'Rollno': 3, 'Name': 'uvw', 'Age': 16}
]

insert(data)
read()
