-- Create Database CBSE24
CREATE DATABASE CBSE24;

-- Use Database CBSE24
USE CBSE24;

-- Create Table DEPARTMENT
CREATE TABLE DEPARTMENT (
    Dept INT PRIMARY KEY,
    Dname VARCHAR(50),
    Entitlement VARCHAR(50)
);

-- Insert Data into DEPARTMENT Table
INSERT INTO DEPARTMENT (Dept, Dname, Entitlement)
VALUES
    (11, 'Sales', 'Taxi'),
    (22, 'Store', 'Air'),
    (33, 'Finance', 'Car');


-- Create Table EMPLOYEE
CREATE TABLE EMPLOYEE (
    Ecode INT PRIMARY KEY,
    eName VARCHAR(50),
    Salary DECIMAL(10,2),
    Zone VARCHAR(20),
    Age INT,
    Grade VARCHAR(10),
    Dept INT,
    FOREIGN KEY (Dept) REFERENCES DEPARTMENT(Dept)
);

-- Insert Data into EMPLOYEE Table
INSERT INTO EMPLOYEE (Ecode, eName, Salary, Zone, Age, Grade, Dept)
VALUES
    (101, 'Mukul', 30000, 'West', 28, 'A', 11),
    (102, 'Kritika', 35000, 'Centre', 51, 'A', 22),
    (103, 'Naveen', 32000, 'East', 40, NULL, 11),
    (104, 'Uday', 38000, 'North', 38, 'C', 33),
    (105, 'Nupur', 32000, 'East', 26, NULL, 11);

-- 1. Display the details of all the employees who are getting a salary of less than 33000.
SELECT * 
FROM EMPLOYEE
WHERE Salary < 33000;

-- 2. Display the sum of salary of Grade ‘B’ employees.
SELECT SUM(Salary) AS TotalSalary
FROM EMPLOYEE
WHERE Grade = 'B';

-- 3. Display the employee name, age and zone of employees in the ascending order of their age of East department.
SELECT eName, Age, Zone
FROM EMPLOYEE
WHERE Dept IN (SELECT Dept FROM DEPARTMENT WHERE Dname = 'East')
ORDER BY Age ASC;

-- 4. Display Employee Code, Employee Name and Department Name for all employees.
SELECT e.Ecode, e.eName, d.Dname
FROM EMPLOYEE e
JOIN DEPARTMENT d ON e.Dept = d.Dept;



