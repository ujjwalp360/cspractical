'''PYTHON PROGRAMMING
Write a Program in Python that defines and calls the following user defined functions:
(i)	ADDPROD() – To accept and add data of a product to a CSV file ‘product.csv’. Each record consists of a list with field elements as prodid, name and price to store product id, employee name and product price respectively.
(ii)	COUNTPROD() – To count the number of records present in the CSV file named ‘product.csv’.
'''

import csv

def ADDPROD(prod_id, name, price):
    with open('product.csv', mode='a+', ) as f:
        w = csv.writer(f)
        w.writerow([prod_id, name, price])

def COUNTPROD():
    with open('product.csv', mode='r') as f:
        r = csv.reader(f)
        c = sum(1 for _ in r)
        return c

# Ex:
ADDPROD('001', 'A', 199)
ADDPROD('002', 'B', 499)

print("Number of products:", COUNTPROD())
