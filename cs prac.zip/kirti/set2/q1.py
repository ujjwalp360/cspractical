'''PYTHON PROGRAMMING
Write a menu-based program to add, delete and display the record of players by using list as Stack in python. (Record of a player contains: Player code, name and Rank). The program should contain following three functions: 
(i) PUSH() – to get the data of 3 players from the user  and add them to stack PLAYER
(ii) POP() – to remove the last record from the  stack PLAYER.
(iii) Display_Player() – To display all records from the stack
'''
p = []

def PUSH():
    for _ in range(3):
        c = input("Code: ")
        n = input("Name: ")
        r = input("Rank: ")
        p.append((c, n, r))
    print("Players added.")

def POP():
    if not p:
        print("No players.")
    else:
        rp = p.pop()
        print(f"Removed: {rp}")

def Display_Player():
    if not p:
        print("No players.")
    else:
        print("Players:")
        for i in p:
            print(f"Code: {i[0]}, Name: {i[1]}, Rank: {i[2]}")

while True:
    print("Menu:")
    print("1. push")
    print("2. pop")
    print("3. display")
    print("4. Quit")
    c = input("Choice: ")
    
    if c == '1':
        PUSH()
    elif c == '2':
        POP()
    elif c == '3':
        Display_Player()
    elif c == '4':
        print("Exit.")
        break
    else:
        print("Invalid.")
