-- Create Database
CREATE DATABASE IF NOT EXISTS CBSE24;
USE CBSE24;

-- Create Table STUDENT
CREATE TABLE IF NOT EXISTS STUDENT (
    Enrol INT PRIMARY KEY,
    SName VARCHAR(50),
    Fee INT,
    House VARCHAR(50),
    Class INT,
    Grade CHAR(2),
    Scode CHAR(4)
);

-- Insert Data into STUDENT Table
INSERT INTO STUDENT (Enrol, SName, Fee, House, Class, Grade, Scode) VALUES
(101, 'Nanda', 5000, 'Green', 11, 'AS', 'S11'),
(102, 'Saurabh', 3000, 'Blue', 12, 'BS', 'S33'),
(103, 'Kamal', 3000, 'Green', 12, NULL, 'S33'),
(105, 'Praveen', 2500, 'Red', 11, 'CS', 'S11'),
(107, 'Arvind', 4500, 'Blue', 12, NULL, 'S22');

-- Create Table STREAM
CREATE TABLE IF NOT EXISTS STREAM (
    Scode CHAR(4) PRIMARY KEY,
    Sname VARCHAR(50),
    Chapters INT
);

-- Insert Data into STREAM Table
INSERT INTO STREAM (Scode, Sname, Chapters) VALUES
('S11', 'Science', 15),
('S22', 'Commerce', 11),
('S33', 'Humanities', 12);
----------------------------------------------------------
SELECT * FROM STUDENT WHERE Fee < 3000;

SELECT SUM(Fee) AS TotalFee FROM STUDENT WHERE Class = 11;

SELECT SName, Class, Fee, House
FROM STUDENT
WHERE House = 'Blue'
ORDER BY Fee ASC;

SELECT s.Enrol, s.SName, st.Sname AS StreamName
FROM STUDENT s
JOIN STREAM st ON s.Scode = st.Scode;

